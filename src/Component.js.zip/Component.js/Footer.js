function Footer() {
    return ( 
     <div className="journey footer">
        <caption></caption>
        <caption className="Footer caption"></caption>
     </div>
    );
};

export default Footer;