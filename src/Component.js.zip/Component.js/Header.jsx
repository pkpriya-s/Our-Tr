
function Header() {
    return ( 
       <div >
          <header className="journey">
      <h1 className="title">My Travel Journey</h1>
       </header>
      </div>
     );
}

export default Header;